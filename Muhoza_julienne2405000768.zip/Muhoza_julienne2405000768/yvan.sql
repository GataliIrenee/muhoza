create database HotelManagementSystem;
use HotelManagementSystem;
create table Clients(ClientID int primary key,Name varchar(100),Location varchar(50),Contract varchar(100));
create table Customers(CustomerID int primary key,Name varchar(100),Email varchar(50),Phone varchar(100),Addressm varchar(200));
create table Orders(OrderID int primary key,ClientID int,CustomerID int,OrderDate varchar(100),TotalAmount varchar(50));
show tables;
desc clients;
insert into clients(ClientID,Name,Location ,Contract)
values(1,"lili","df","jhj"),
       (2,"kuku","hj","jk"),
       (3,"lol","ed","uj");
       desc customers;
       
       insert into customers(customerID,Name,Email,Phone,Addressm)
       values(11,"tg","thierry@gmail.com",0770945,"dffg"),
              (12,"tj","thier@gmail.com",07709456,"dopfg"),
              (13,"tef","innocent@gmail.com",07809476,"popfg");
              select * from customers;
              drop table customers;
              desc orders;
              insert into Orders(OrderID,ClientID,CustomerID,OrderDate,TotalAmount)
              values(22,1,11,"gjj","100"),
                    (33,2,12,"gjj","1000"),
                       (44,3,13,"gjj","2000");
         -- counting 
         select count(OrderID) from Orders;
         select count(Name) from Clients;
         select count(CustomerID) from Customers;
         update Clients 
         SET Location="musanze"
         WHERE ClientID=2;
         select * from Clients;
          select sum(ClientID) from Clients;
          select sum(CustomerID) from Customers;
          -- AVEREGE
           select avg(ClientID) from Clients;
           select avg(CustomerID) from Customers;
           -- create view
           create view listCustomer as select * from Customers;
           select * from listCustomer;
                create view listClients as select * from Clients;
                 create view lisOrders as select * from Orders;
                   select * from listOrders;
                  
-- Stored Procedures

-- Procedure to add a new client
DELIMITER $$
CREATE PROCEDURE addClient(
    IN ClientIDparam INT,
    IN Nameparam VARCHAR(100),
    IN Locationparam VARCHAR(50),
    IN Contractparam VARCHAR(100)
)
BEGIN
    INSERT INTO Clients (ClientID, Name, Location, Contract) 
    VALUES (ClientIDparam, Nameparam, Locationparam, Contractparam);
END $$
DELIMITER ;

-- Procedure to add a new customer
DELIMITER $$
CREATE PROCEDURE addCustomer(
    IN CustomerIDparam INT,
    IN Nameparam VARCHAR(100),
    IN Emailparam VARCHAR(50),
    IN Phoneparam VARCHAR(100),
    IN Addressmparam VARCHAR(200)
)
BEGIN
    INSERT INTO Customers (CustomerID, Name, Email, Phone, Addressm) 
    VALUES (CustomerIDparam, Nameparam, Emailparam, Phoneparam, Addressmparam);
END $$
DELIMITER ;

-- Procedure to add a new order
DELIMITER $$
CREATE PROCEDURE addOrder(
    IN OrderIDparam INT,
    IN ClientIDparam INT,
    IN CustomerIDparam INT,
    IN OrderDateparam VARCHAR(100),
    IN TotalAmountparam VARCHAR(50)
)
BEGIN
    INSERT INTO Orders (OrderID, ClientID, CustomerID, OrderDate, TotalAmount) 
    VALUES (OrderIDparam, ClientIDparam, CustomerIDparam, OrderDateparam, TotalAmountparam);
END $$
DELIMITER ;

-- Procedure to update client location
DELIMITER $$
CREATE PROCEDURE updateClientLocation(
    IN ClientIDparam INT,
    IN NewLocation VARCHAR(50)
)
BEGIN
    UPDATE Clients SET Location = NewLocation WHERE ClientID = ClientIDparam;
END $$
DELIMITER ;
                                DELIMITER $$      
                    
                     create procedure addOrders(
                   IN OrderIDparam INT,
                   IN Nameparam varchar(100),
                   IN Emailparam INT,
                   IN Phone varchar(100),
                   IN Addressm varchar(100)
                   ) 
                   BEGIN
                   insert into Customers values(CustomerIDparam,Nameparam,Emailparam,Phone,Addressm);
                   END $$
                      DELIMITER ;
                      select * from clients;
                      
                      DELIMITER $$
                      CREATE PROCEDURE upclient(in clientIDp int)
                      begin
                      update clients set location='kigali' where clientID=clientIDp;
                      end $$
                      delimiter ;
                      call upclient(3);
                      
-- Trigger 1: Ensure TotalAmount is positive before inserting into Orders
DELIMITER $$
CREATE TRIGGER before_insert_order
BEFORE INSERT ON Orders
FOR EACH ROW
BEGIN
    IF NEW.TotalAmount <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'TotalAmount must be a positive number.';
    END IF;
END$$
DELIMITER ;

-- Trigger 2: Log new customer addition
DELIMITER $$
CREATE TRIGGER after_insert_customer
AFTER INSERT ON Customers
FOR EACH ROW
BEGIN
    INSERT INTO Logs (LogMessage) 
    VALUES (CONCAT('New customer added: ', NEW.Name));
END$$
DELIMITER ;

-- Triggers

-- Trigger to log every new order
DELIMITER $$
CREATE TRIGGER after_order_insert
AFTER INSERT ON Orders
FOR EACH ROW
BEGIN
    INSERT INTO OrderLog (OrderID, Action) VALUES (NEW.OrderID, 'INSERT');
END $$
DELIMITER ;

-- Trigger to update LastUpdated field on Clients
DELIMITER $$
CREATE TRIGGER before_client_update
BEFORE UPDATE ON Clients
FOR EACH ROW
BEGIN
    SET NEW.LastUpdated = CURRENT_TIMESTAMP;
END $$
DELIMITER ;

-- Trigger to update LastUpdated field on Customers
DELIMITER $$
CREATE TRIGGER before_customer_update
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    SET NEW.LastUpdated = CURRENT_TIMESTAMP;
END $$
DELIMITER ;
	-- creation of user
	create user 'muhoza'@'127.0.0.1' identified by '2405000768';
	grant all privileges on *.* to 'muhoza'@'127.0.0.1';
	flush privileges;
                      
                      
                      
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                    
                    
                   
                     
           
          
         